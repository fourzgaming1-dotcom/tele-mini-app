# Telegram Mini App + Stripe Wallet

A minimal, working "deposit with Stripe → spend inside the mini app" system:

- **Deposit**: user taps an amount in the mini app → Stripe Checkout opens →
  on success, Stripe calls your webhook → your server credits their balance.
- **Spend**: user buys a store item inside the mini app → balance is deducted
  instantly from your database.
- Balance lives in **your** database, not Stripe. Stripe is only used to move
  real money in; spending happens against the number in your DB.

This is a starting point, not a finished payments product — read
"Before you launch for real" at the bottom before handling real money.

## How it fits your existing bot

You said your bot is already built and deployed. This project is a
**separate small web server** (it doesn't touch your bot's code) plus a
**web page** (the mini app) that Telegram opens inside a webview. You wire
them together with two things:

1. Your bot needs a button/command that opens the mini app URL (a `WebApp`
   button, or the Menu Button set via BotFather).
2. This server needs your bot's token, only to verify that requests really
   came from Telegram (see `telegramAuth.js` — no messages are sent from
   here).

## Project layout

```
telegram-stripe-miniapp/
├── server.js          Express app: API routes + Stripe webhook
├── db.js               SQLite schema + balance/transaction logic
├── telegramAuth.js     Verifies Telegram initData (HMAC check)
├── public/
│   ├── index.html       The mini app UI (balance, deposit, store)
│   ├── success.html      Shown after a successful Stripe payment
│   └── cancel.html        Shown if the user cancels checkout
├── .env.example
└── package.json
```

## 1. Install and run locally

```bash
cd telegram-stripe-miniapp
npm install
cp .env.example .env
# edit .env with your real values (see below)
npm start
```

The server starts on `http://localhost:3000`. `data.sqlite` is created
automatically on first run — it's your whole database, one file.

## 2. Get your Stripe keys

1. Sign in at https://dashboard.stripe.com — use **Test mode** first.
2. Copy your **Secret key** from https://dashboard.stripe.com/apikeys into
   `STRIPE_SECRET_KEY`.
3. Leave `STRIPE_WEBHOOK_SECRET` for step 4.

## 3. Deploy the server somewhere with a public HTTPS URL

Telegram Mini Apps and Stripe webhooks both require HTTPS. Any of these
work with basically no config (all have free tiers):

- **Render** (render.com) — "New Web Service", connect your GitHub repo,
  build command `npm install`, start command `npm start`.
- **Railway** (railway.app) — same idea, detects Node automatically.
- **Fly.io** — `fly launch` in this folder.

Whichever you pick:
- Set all the variables from `.env.example` in that host's dashboard
  (do **not** commit your real `.env` file — it's already in `.gitignore` below).
- Set `PUBLIC_URL` to the exact HTTPS URL the host gives you, no trailing
  slash (e.g. `https://your-app.onrender.com`).
- SQLite needs a **persistent disk** — on Render/Railway add a small
  persistent volume mounted at the project folder, or switch to their
  managed Postgres later (see "Swapping SQLite for Postgres" below).

## 4. Create the Stripe webhook

1. In the Stripe Dashboard: **Developers → Webhooks → Add endpoint**.
2. Endpoint URL: `https://YOUR_PUBLIC_URL/webhook/stripe`
3. Select event: `checkout.session.completed`
4. Save, then copy the **Signing secret** (starts with `whsec_`) into
   `STRIPE_WEBHOOK_SECRET` on your host, and redeploy.

While developing locally, use the Stripe CLI instead of a real deployed
webhook:

```bash
stripe login
stripe listen --forward-to localhost:3000/webhook/stripe
# this prints a whsec_... — put that in your local .env
```

## 5. Point your bot at the mini app

In BotFather:

```
/mybots → choose your bot → Bot Settings → Menu Button → Configure Menu Button
```

Set the URL to your deployed `PUBLIC_URL` (e.g.
`https://your-app.onrender.com`). Now the menu button opens the wallet.

Alternatively, send an inline button from your existing bot code:

```js
// wherever you already send messages from your bot
bot.sendMessage(chatId, "Open your wallet:", {
  reply_markup: {
    inline_keyboard: [[
      { text: "💳 Open Wallet", web_app: { url: "https://your-app.onrender.com" } }
    ]]
  }
});
```

Also replace the `https://t.me/` links in `public/success.html` and
`public/cancel.html` with `https://t.me/your_bot_username` so the button
sends people back to the right place.

## How the money flow actually works

1. User opens the mini app → `GET /api/me` verifies their Telegram
   `initData` and returns their balance (creating the user row if new).
2. User taps "$10" → `POST /api/deposit` creates a Stripe Checkout Session
   tagged with `metadata.telegram_id`, and returns the checkout URL.
3. The mini app opens that URL via `Telegram.WebApp.openLink` (Stripe
   Checkout must open in the system browser, not the in-app webview).
4. User pays. Stripe redirects them to `success.html` and, independently,
   **calls your webhook** (`POST /webhook/stripe`) with a signed event.
5. The webhook handler verifies the signature, then credits the balance in
   SQLite — keyed off `stripe_session_id` so a retried webhook can never
   double-credit someone.
6. User returns to the bot and reopens the mini app (or just switches back
   to it) → the page listens for `visibilitychange` and refetches
   `/api/me`, showing the new balance.
7. Spending an item calls `POST /api/spend`, which checks the balance and
   deducts it in the same SQLite transaction — no way to go negative.

## Customizing the store

Edit the seed list in `db.js` (`itemCount === 0` block) or just insert rows
directly into the `items` table — no code changes needed elsewhere.

## Swapping SQLite for Postgres later

`db.js` is intentionally the only file that talks to the database. When you
outgrow a single SQLite file (e.g. deploying to a host without persistent
disks, or wanting multiple server instances), rewrite `db.js` against
Postgres (e.g. with `pg` or `Prisma`) keeping the same exported function
names — `server.js` doesn't need to change.

## Before you launch for real

- Switch Stripe from test keys to live keys, and create a **second**
  live-mode webhook endpoint (test and live have separate webhook secrets).
- Add rate limiting to `/api/deposit` and `/api/spend` (e.g. `express-rate-limit`).
- Decide what "spend" actually delivers — right now purchases just deduct
  balance and log a transaction; wire `POST /api/spend` up to whatever your
  product actually is (unlocking content, crediting an in-game currency,
  triggering a bot message, etc.).
- Consider Stripe's [Radar](https://stripe.com/radar) fraud rules and
  refund/chargeback handling — a chargeback won't automatically remove the
  balance you already credited, so decide how you want to handle that.
- Back up `data.sqlite` regularly, or move to managed Postgres.
